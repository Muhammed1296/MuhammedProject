export class Alarm {
    id;
    time;
    mode = false;

    constructor(id, time, mode) {
        this.id = id;
        this.time = time;
        this.mode = mode;
    }
}