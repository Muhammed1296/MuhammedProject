export class AllAlarms {

    array = [];

    constructor() {
        this.array = JSON.parse(localStorage.getItem('alarms')) ?? [];
    }

    save() {
        localStorage.setItem('alarms', JSON.stringify(this.array));
    }

    add(alarm) {
        this.array.push(alarm);
        this.save();
    }

    switchMode(id) {
        const index = this.array.findIndex(c => c.id === id);
        this.array[index].mode = !this.array[index].mode;
        this.save();

    }

    remove(id) {
        this.array = this.array.filter(c => c.id !== id);
        this.save();
    }

}