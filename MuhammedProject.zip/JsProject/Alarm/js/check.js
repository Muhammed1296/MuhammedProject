// import { Alarm } from "./alarm";

const container = document.getElementById('container');
const alarmsDiv = document.getElementById('alarms');
const title = document.getElementById('title');
const addDiv = document.getElementById('add');

let ringDiv = document.createElement('div');
ringDiv.classList.add('ringDiv');

let h1 = document.createElement('h1');
h1.innerText = 'Time to wake up';

let ringImg = document.createElement('img');
ringImg.src = '../ring.png';
ringImg.classList.add('ringImg');

let beat = new Audio();
// beat.src = '../morning.wav';
beat.src = '../morning.wav' ?? '../ring2.wav';
beat.loop = true;

let wokeBtn = document.createElement('button');
wokeBtn.innerText = 'Woke up';

ringDiv.appendChild(h1);
ringDiv.appendChild(ringImg);
ringDiv.appendChild(beat);
ringDiv.appendChild(wokeBtn);

container.appendChild(ringDiv);
ringDiv.style.display = 'none';

wokeBtn.addEventListener('click', () => {
    beat.pause();
    ringDiv.style.display = 'none';
    alarmsDiv.style.display = 'initial';
    title.style.display = 'initial';
    console.log('turning off');
    // render();
})

// addDiv.insertAdjacentElement('afterend', ringDiv);

export function getCurrent() {

    let date = new Date();
    let h = date.getHours().toString().padStart(2, '0');
    let m = date.getMinutes().toString().padStart(2, '0');

    let current = `${h}:${m}`;
    return current;
}

export function ring() {

    // beat.play();

    try {
        beat.play();
    } catch (error) {
        console.error('An error occurred while trying to play audio:', error);
    }

    ringDiv.style.display = '';

}


