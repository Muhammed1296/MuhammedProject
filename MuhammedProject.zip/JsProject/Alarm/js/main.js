import { Alarm } from './alarm.js';
import { nanoid } from 'https://cdn.jsdelivr.net/npm/nanoid@5.0.6/+esm';
import { AllAlarms } from './allAlarms.js';
import { getCurrent, ring } from './check.js';
import { compareTimes } from './sortTimes.js';
// import './check';

const addBtn = document.getElementById('addBtn');
const editBtn = document.getElementById('editBtn');
const alarmList = document.getElementById('alarmList');
const container = document.getElementById('container');
const alarmsDiv = document.getElementById('alarms');
const titleD = document.getElementById('title');
// const timeSet=document.getElementById('timeSet');
// let elements = document.querySelectorAll('.removeB');
let editMode = false;



let alarms = new AllAlarms();

addBtn.addEventListener('click', () => {

    addBtn.style.display = 'none';
    let selectedTime;
    let setAlarm = document.createElement('div');
    setAlarm.classList.add('setAlarm');

    let title = document.createElement('h1');
    title.innerText = 'Setting alaram at: ';

    let pick = document.createElement('input');
    pick.id = 'timePick';
    pick.type = 'time';
    pick.addEventListener('change', function () {
        selectedTime = this.value;
    });

    let confirmBtn = document.createElement('button');
    confirmBtn.innerText = 'Confirm';
    confirmBtn.addEventListener('click', (e) => {
        addBtn.style.display = 'initial';
        // console.log(selectedTime);
        // console.log(selectedTime.value);

        let exist = false;
        alarms.array.forEach(item => {
            if (item.time == selectedTime)
                exist = true;
        })

        if (!exist) {
            let newA = new Alarm(nanoid(), selectedTime, false);
            alarms.add(newA);
            alarms.switchMode(newA.id);
            render();
            // document.getElementById(`${newA.id}`).click();


        }
        setAlarm.remove();
    });

    let cancelmBtn = document.createElement('button');
    cancelmBtn.innerText = 'Cancel';
    cancelmBtn.addEventListener('click', () => {
        addBtn.style.display = 'initial';
        setAlarm.remove();
    });

    setAlarm.appendChild(title);
    setAlarm.appendChild(pick);
    setAlarm.appendChild(confirmBtn);
    setAlarm.appendChild(cancelmBtn);

    container.insertBefore(setAlarm, titleD);
})


editBtn.addEventListener('click', () => {
    let elements = document.querySelectorAll('.removeB');
    editMode = !editMode;

    if (editMode) {
        editBtn.innerText = 'Done';
        elements.forEach(function (element) {
            element.style.display = 'initial';
        });
        // render();
    }
    else {
        editBtn.innerHTML = `Edit <i class="fa fa-pencil" aria-hidden="true"></i>`;
        elements.forEach(function (element) {
            element.style.display = 'none';
        });
        editMode = false;
    }
    // render();
}
)

// let rang = false;
setInterval(() => {
    let current = getCurrent();
    alarms.array.forEach(item => {


        if (item.mode && current == item.time) {
            alarms.switchMode(item.id);
            render();
            alarmsDiv.style.display = 'none';
            titleD.style.display = 'none';
            ring();
            setTimeout(() => {
                alarms.switchMode(item.id);
                render();
            }, 60000)
        }


        /*  if (item.mode) {
             if (current == item.time) {
 
 
                 setTimeout(() => {
 
 
                     let newA = new Alarm(nanoid(), item.time, false);
                     alarms.add(newA);
                     alarms.switchMode(newA.id);
                     render();
 
                     console.log('diss');
                 }, 60000)
 
                 alarms.remove(item.id);
                 render();
                 alarmsDiv.style.display = 'none';
                 titleD.style.display = 'none';
                 ring();
             }
         } */

    })
}, 1000)

function render() {

    alarmList.innerHTML = '';

    alarms.array.forEach(item => {
        let li = document.createElement('li');

        let timing = document.createElement('h2');
        timing.innerText = item.time;

        let label = document.createElement('label');
        label.classList.add('switch');
        let input = document.createElement('input');
        input.type = 'checkbox';
        let span = document.createElement('span');
        span.classList.add('slider', 'round');
        span.id = item.id;
        span.addEventListener('click', () => {

            alarms.switchMode(item.id);
            console.log(item.mode);

        });
        if (item.mode)
            input.click();


        label.appendChild(input);
        label.appendChild(span);

        let removeB = document.createElement('button');
        removeB.classList.add('removeB');
        removeB.innerHTML = '<i class="fa fa-trash" aria-hidden="true"></i>';
        removeB.addEventListener('click', () => {
            alarms.remove(item.id);
            render();
        })
        if (!editMode)
            removeB.style.display = 'none';


        li.appendChild(removeB);
        li.appendChild(timing);
        li.appendChild(label);


        alarmList.appendChild(li);
        alarms.array.sort(compareTimes);
    })
}


render();

