export function compareTimes(time1, time2) {
    const [hours1, minutes1] = time1.time.split(":").map(Number);
    const [hours2, minutes2] = time2.time.split(":").map(Number);

    if (hours1 !== hours2) {
        return hours1 - hours2;
    }

    return minutes1 - minutes2;
}