let inputRow = document.getElementById('typingI');
let res = null;

function clearTyping() {
    inputRow.value = '';
    inputRow.style.backgroundColor = 'white';
    inputRow.placeholder = 'Thanks for using my calculator';
    res = 0;
}

function removeLast() {
    inputRow.value = inputRow.value.slice(0, -1);
}

function numberType(value) {
    inputRow.style.backgroundColor = '#ccc';
    inputRow.style.color = 'white';

    inputRow.value += value;
    num1 = inputRow.value;
}

function opType(value) {
    if (!inputRow.value.endsWith(value)) {
        inputRow.value += value;
    }
}

function piType() {
    inputRow.style.backgroundColor = '#ccc';
    inputRow.style.color = 'white';
    inputRow.value += "3.14";
}


function calculate() {

    let line = inputRow.value;
    let arr = line.split('');

    /*   //double operator
      for (let f = 0; f < arr.length; f++) {
          if (isNaN(arr[f]) && isNaN(arr[f + 1]) && arr[f] == arr[f + 1]) {
              if (arr[f] != '-')
                  arr.splice(i + 1, 1);
          }
      } */


    for (let i = 0; i < arr.length - 1; i++) {

        //if first N is negative
        if (arr[0] == '-') {
            arr[0] += arr[1];
            arr.splice(1, 1);
        }

        //reBuild the number
        while ((!(isNaN(arr[i])) || arr[i] == '.') && (!(isNaN(arr[i + 1])) || arr[i + 1] == '.')) {

            arr[i] = arr[i] + arr[i + 1];
            arr.splice(i + 1, 1);
        }

        // 1*-4
        if (isNaN(arr[i]) && arr[i] != '-' && arr[i + 1] == '-') {
            arr[i + 1] += arr[i + 2];
            arr.splice(i + 2, 1);
        }
        //all good so far

    }
    // console.log(arr);
    // }



    //if theres still something to calculate
    while (arr.length >= 3) {

        let c = 0;
        /*  if (arr[c + 2] == '-') {
             arr[c + 2] += arr[c + 3];
             arr.splice(c + 3, 1);
         } */

        //first do the * & /
        while (arr.includes('*') || arr.includes('/')) {
            let z = 0;
            for (let z = 0; z < arr.length - 1; z++) {
                /* if (isNaN(arr[z]) && isNaN(arr[z + 1]) && arr[z] === arr[z + 1]) {
                    arr.splice(z + 1, 1);
                } */
                if (arr[z + 1] == '*' || arr[z + 1] == '/') {
                    res = checkOp(arr[z], arr[z + 1], arr[z + 2]);
                    arr[z] = res;
                    arr.splice(z + 1, 2);
                }
            }
        }
        if (arr.length == 1) {
            inputRow.value = res;
            return;
        }
        res = checkOp(arr[c], arr[c + 1], arr[c + 2]);
        arr[c] = res;
        arr.splice(c + 1, 2);
    }

    inputRow.value = res;
}
// }

function checkOp(num1, op, num2) {
    switch (op) {
        case '+':
            return +num1 + +num2;
            break;
        case '-':
            return +num1 - +num2;
            break;
        case '*':
            return +num1 * +num2;
            break;
        case '/':
            return +num1 / +num2;
            break;
    }
}
