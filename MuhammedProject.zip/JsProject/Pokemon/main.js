let mainI = document.getElementById('mainI');

let li1 = document.getElementById('li1');
let li2 = document.getElementById('li2');
let li3 = document.getElementById('li3');
let li4 = document.getElementById('li4');
let allItems = document.querySelectorAll('li');
let currentPokemon;

allItems.forEach(item => {
    item.addEventListener('click', checkAns);
}
);

let pokemons = [];
let solvedPokemons = new Set();

const fetchPokemon = () => {

    const promises = [];
    for (let i = 1; i <= 150; i++) {
        const url = `https://pokeapi.co/api/v2/pokemon/${i}`;
        promises.push(fetch(url).then((res) => res.json()));
    }

    Promise.all(promises).then((results) => {
        pokemons = results.map((result) => ({
            name: result.name.charAt(0).toUpperCase() + result.name.slice(1),
            image: result.sprites['front_default'],
        }));
        randPokemon(pokemons);
    });
};

fetchPokemon();

function randPokemon(pokemons) {
    //random pokemon

    let pokemon = pokemons[Math.floor(Math.random() * pokemons.length)];
    while (solvedPokemons.has(pokemon)) {
        pokemon = pokemons[Math.floor(Math.random() * pokemons.length)];

    }
    currentPokemon = pokemon;
    if (solvedPokemons.size >= 120)
        solvedPokemons.clear();
    solvedPokemons.add(pokemon);

    newQuizz(currentPokemon);
}

const newQuizz = (pokemon) => {
    let names = new Set();
    names.add(pokemon.name);

    mainI.src = pokemon.image;
    //random li
    let rand = 1 + Math.floor(Math.random() * 4);
    let rightO = document.getElementById(`li${rand}`);
    rightO.innerText = pokemon.name;


    allItems.forEach(item => {
        if (item.innerText == '' || item.innerText != pokemon.name) {
            let wrongPokemon = pokemons[Math.floor(Math.random() * pokemons.length)].name;
            while (names.has(wrongPokemon)) {
                wrongPokemon = pokemons[Math.floor(Math.random() * pokemons.length)].name;
            }
            item.innerText = wrongPokemon;
            names.add(wrongPokemon);
        }
    })
}


function checkAns(event) {
    if (event.target.innerText == currentPokemon.name) {
        event.target.classList.add('rightAns');
        setTimeout(function () {
            clear();
            randPokemon(pokemons);
        }, 1500);
        // console.log('right answer');

    }
    else {
        event.target.classList.add('wrongAns');
        // console.log('wrong answer');
    }
}


function clear() {
    allItems.forEach(element => {
        element.innerText = '';
        element.classList.remove('wrongAns');
        element.classList.remove('rightAns');
    })
    // console.log("cleared");
}

