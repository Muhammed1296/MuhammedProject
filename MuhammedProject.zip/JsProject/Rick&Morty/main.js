
const container = document.getElementById('container');

async function showCharacters() {
    const url = `https://rickandmortyapi.com/api/character/?page=1`;

    const res = await fetch(url);
    const json = await res.json()

    // console.log(json.results);

    json.results.forEach(char => {
        const div = document.createElement('div');
        div.className = 'card';

        const name = document.createElement('h3');
        name.innerText = char.name;
        const planet = document.createElement('p');
        planet.innerText = char.origin.name;
        const gender = document.createElement('p');
        gender.innerText = char.gender;
        const species = document.createElement('p');
        species.innerText = char.species;
        const img = document.createElement('img');
        img.src = char.image ?? 'images/title.png';

        div.appendChild(img);
        div.appendChild(name);
        div.appendChild(planet);
        div.appendChild(species);
        div.appendChild(gender);

        container.appendChild(div);

    });
}

showCharacters();