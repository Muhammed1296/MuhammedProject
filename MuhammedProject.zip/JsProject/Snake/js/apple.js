import { eat, add } from './snake.js'
import { randomGridPosotion } from './border.js';

let apple = randomApple();
let units = 1;

export function update() {
    if (eat(apple)) {
        add(units)
        apple = randomApple();
    }
}

export function locate() {
    const appleCell = document.createElement('div');
    appleCell.style.gridRowStart = apple.y;
    appleCell.style.gridColumnStart = apple.x;
    appleCell.id = 'apple';
    gameArea.appendChild(appleCell);

}

function randomApple() {
    let newApple

    while (newApple == null || eat(newApple)) {
        newApple = randomGridPosotion();
    }
    return newApple;
}