let dir = { x: 0, y: 0 };
let lastDir = { x: 0, y: 0 };
let gameSize = 25;
export let clicks = 0;

window.addEventListener('keydown', c => {
    switch (c.key) {
        case 'ArrowUp':
            if (lastDir.y != 0) return;
            dir = { x: 0, y: -1 };
            clicks++;
            break;
        case 'ArrowDown':
            if (lastDir.y != 0) return;
            dir = { x: 0, y: 1 };
            clicks++;
            break;
        case 'ArrowLeft':
            if (lastDir.x != 0) return;
            dir = { x: -1, y: 0 };
            clicks++;
            break;
        case 'ArrowRight':
            if (lastDir.x != 0) return;
            dir = { x: 1, y: 0 };
            clicks++;
            break;
    }
})

export function getDir() {
    lastDir = dir;
    return dir;
}

export function randomGridPosotion() {
    return {
        x: Math.floor(Math.random() * gameSize) + 1,
        y: Math.floor(Math.random() * gameSize) + 1
    }
}

export function outSide(position) {
    return (position.x < 1 || position.x > gameSize || position.y < 1 || position.y > gameSize)
}