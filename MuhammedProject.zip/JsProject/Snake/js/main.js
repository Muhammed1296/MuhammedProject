import {
    update as updateSnake, locate as locateSnake, speed, ateItSelf, getHead
} from './snake.js';
import {
    update as updateApple, locate as locateApple
} from './apple.js';
import { outSide } from './border.js';

const gameArea = document.getElementById('gameArea');
let lastR = 0;
let gameOver = false;


export let startTime; // to keep track of the start time
export let stopwatchInterval; // to keep track of the interval
export let elapsedPausedTime = 0; // to keep track of the elapsed time while stopped

function render(zeroP) {
    if (gameOver) {
        stopStopwatch();
        if (confirm('OOOps, would you like to play again?')) {
            resetStopwatch();
            window.location = '../Snake.html';
        }

        return;
    }

    window.requestAnimationFrame(render);
    const sinceLast = (zeroP - lastR) / 1000;
    if (sinceLast < 1 / speed) return

    lastR = zeroP;

    update();
    locate();
}

function update() {

    updateSnake();
    updateApple();
    check();
}

function locate() {
    gameArea.innerHTML = '';
    locateSnake(gameArea);
    locateApple(gameArea);
}

function check() {
    gameOver = outSide(getHead()) || ateItSelf();
}

window.requestAnimationFrame(render);

export function startStopwatch() {
    if (!stopwatchInterval) {
        startTime = new Date().getTime() - elapsedPausedTime;
        stopwatchInterval = setInterval(updateStopwatch, 1000);
    }
}

export function stopStopwatch() {
    clearInterval(stopwatchInterval);
    elapsedPausedTime = new Date().getTime() - startTime;
    stopwatchInterval = null;
}

export function resetStopwatch() {
    stopStopwatch();
    elapsedPausedTime = 0;
    document.getElementById("timer").innerHTML = "00:00:00";
}

export function updateStopwatch() {
    let currentTime = new Date().getTime();
    let elapsedTime = currentTime - startTime;
    let seconds = Math.floor(elapsedTime / 1000) % 60;
    let minutes = Math.floor(elapsedTime / 1000 / 60) % 60;
    let hours = Math.floor(elapsedTime / 1000 / 60 / 60);
    let displayTime = pad(hours) + ":" + pad(minutes) + ":" + pad(seconds);
    document.getElementById("timer").innerHTML = displayTime;
}

export function pad(number) {
    return (number < 10 ? "0" : "") + number;
}