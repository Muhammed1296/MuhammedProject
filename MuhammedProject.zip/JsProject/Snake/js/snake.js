import { getDir } from "./border.js";
import { startStopwatch } from "./main.js";
import { clicks } from "./border.js";

export let speed = 8;
let snakeB = [{ x: 1, y: 1 }];
let newCell = 0;

let snakeL = document.getElementById('length');
let maxScore = document.getElementById('maxScore');

let max = parseInt(localStorage.getItem('maxScore')) || 0;
localStorage.setItem('maxScore', max);
maxScore.innerText = `Max score: ${max}`;

export function update() {
    if (clicks == 1) {
        startStopwatch();
    }
    grow();
    let dir = getDir();
    for (let i = snakeB.length - 2; i >= 0; i--) {
        snakeB[i + 1] = { ...snakeB[i] }
    }

    snakeB[0].x += dir.x;
    snakeB[0].y += dir.y;
    snakeL.innerText = `Score: ${snakeB.length - 1}`;

    if (snakeB.length - 1 > max) {
        max = snakeB.length - 1;
        localStorage.setItem('maxScore', max);
        maxScore.innerText = `Max score: ${max}`;
    }

}

export function locate(gameArea) {
    snakeB.forEach(cell => {
        const snakeCell = document.createElement('div');
        snakeCell.style.gridRowStart = cell.y;
        snakeCell.style.gridColumnStart = cell.x;
        snakeCell.id = 'snake';
        gameArea.appendChild(snakeCell);

    })
}

export function add(units) {
    newCell += units;
}

export function eat(position, { ignoreHead = false } = {}) {
    return snakeB.some((cell, index) => {
        if (ignoreHead && index == 0)
            return false;
        return equalPositions(cell, position)
    })
}

function equalPositions(pos1, pos2) {
    return pos1.x === pos2.x && pos1.y === pos2.y;
}

function grow() {
    for (let i = 0; i < newCell; i++) {
        snakeB.push({ ...snakeB[snakeB.length - 1] })
    }
    newCell = 0;
}

export function getHead() {
    return snakeB[0];
}

export function ateItSelf() {
    return eat(snakeB[0], { ignoreHead: true })
}