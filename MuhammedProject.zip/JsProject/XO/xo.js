let btn1 = document.getElementById('x');
let btn2 = document.getElementById('o');
let resetB = document.getElementById('reset');
let chatRes = document.getElementById('chat-res');
let chat = document.getElementById('chat');
let title = document.getElementById('title');
let welcome = document.getElementById('welcome');
let boxes = document.getElementsByClassName('box');
let bgi = document.getElementById('bgi');

Array.from(boxes).forEach(div => {
    div.addEventListener('click', play);
});

resetB.addEventListener('click', reset);

chat.value = 'Your turn';

let player;
let comp;
let playerTurn = true;

let arr = ['box1', 'box2', 'box3', 'box4', 'box5', 'box6', 'box7', 'box8', 'box9'];

let b1 = document.getElementById('box1');
let b2 = document.getElementById('box2');
let b3 = document.getElementById('box3');
let b4 = document.getElementById('box4');
let b5 = document.getElementById('box5');
let b6 = document.getElementById('box6');
let b7 = document.getElementById('box7');
let b8 = document.getElementById('box8');
let b9 = document.getElementById('box9');

b1.value = 0;
b2.value = 0;
b3.value = 0;
b4.value = 0;
b5.value = 0;
b6.value = 0;
b7.value = 0;
b8.value = 0;
b9.value = 0;

let clicks = 0;

//choose player
btn1.addEventListener('click', (e) => {
    player = e.target.value;
    comp = btn2.value;
    // welcome.remove();
    welcome.style.display = 'none';
    chatRes.style.display = 'flex'; chatRes.style.flexDirection = "column";
    bgi.classList.add('reveal');
});

btn2.addEventListener('click', (e) => {
    player = e.target.value;
    comp = btn1.value;
    // welcome.remove();
    welcome.style.display = 'none';
    chatRes.style.display = 'flex'; chatRes.style.flexDirection = "column";
    bgi.classList.add('reveal');
});


//player turn
function play(event) {


    if (playerTurn) {
        //player move
        let targetE = event.target;
        targetE.innerText = player;
        targetE.value = 1;
        targetE.removeEventListener('click', play);

        //remove filled box
        arr.splice(arr.indexOf(targetE.id), 1);
        // console.log(...arr);

        clicks++;

        //check if its a tie
        if (arr.length <= 1 && !checkPlayer() && !checkComputer()) {
            chat.value = `We have a tie! `;
            setTimeout(reset, 1800);
        }

        //check if there is a winner
        setTimeout(checkPlayer, 1000);

        //computer move
        if (!checkPlayer()) {
            setTimeout(compPlay, 1400);
            chat.value = 'Wait please';
        }

        playerTurn = false;
    }
}


let first2 = true;

//computer turn
function compPlay() {

    first2 = clicks >= 2 ? false : true;
    let rand = Math.floor(Math.random() * arr.length);
    if (clicks == 1) {
        if (b1.value == 1) {
            while (arr[rand] == 'box6' || arr[rand] == 'box8') {
                rand = Math.floor(Math.random() * arr.length);
            }
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
        else if (b2.value == 1) {
            while (arr[rand] == 'box4' || arr[rand] == 'box6' || arr[rand] == 'box7' || arr[rand] == 'box9') {
                rand = Math.floor(Math.random() * arr.length);
            }
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
        else if (b3.value == 1) {
            while (arr[rand] == 'box4' || arr[rand] == 'box8') {
                rand = Math.floor(Math.random() * arr.length);
            }
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
        else if (b4.value == 1) {
            while (arr[rand] == 'box2' || arr[rand] == 'box3' || arr[rand] == 'box8' || arr[rand] == 'box9') {

                rand = Math.floor(Math.random() * arr.length);
            }
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
        else if (b5.value == 1) {
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
        else if (b6.value == 1) {
            while (arr[rand] == 'box1' || arr[rand] == 'box2' || arr[rand] == 'box7' || arr[rand] == 'box8') {
                rand = Math.floor(Math.random() * arr.length);
            }
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
        else if (b7.value == 1) {
            while (arr[rand] == 'box2' || arr[rand] == 'box6') {
                rand = Math.floor(Math.random() * arr.length);
                compTurn = document.getElementById(`${arr[rand]}`);
                compTurn.innerText = comp;
                compTurn.value = 2;
                compTurn.removeEventListener('click', play);
                arr.splice(arr.indexOf(compTurn.id), 1);
            }
        }
        else if (b8.value == 1) {
            while (arr[rand] == 'box1' || arr[rand] == 'box3' || arr[rand] == 'box4' || arr[rand] == 'box6') {
                rand = Math.floor(Math.random() * arr.length);
            }
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
        else if (b9.value == 1) {
            while (arr[rand] == 'box2' || arr[rand] == 'box4') {
                rand = Math.floor(Math.random() * arr.length);
            }
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
            compTurn.removeEventListener('click', play);
            arr.splice(arr.indexOf(compTurn.id), 1);
        }
    }
    else
        if (clicks == 2) {

            //compuer move
            /*   
              let rand = Math.floor(Math.random() * arr.length);
              console.log(rand);
  
              if (arr.length > 0) {
                  compTurn = document.getElementById(`${arr[rand]}`);
                  compTurn.innerText = comp;
                  compTurn.value = 2;
              }
  
              //remove filled box
              compTurn.removeEventListener('click', play);
              arr.splice(arr.indexOf(compTurn.id), 1);
              // console.log(...arr);

        } else { */

            if (((b1.value == 1 && b2.value == 1) || (b6.value == 1 && b9.value == 1) || (b7.value == 1 && b5.value == 1)) && b3.value == 0) {
                b3.innerText = comp;
                b3.value = 2;
                b3.removeEventListener('click', play);
                arr.splice(arr.indexOf(b3.id), 1);
                // return;
            } else
                if (((b2.value == 1 && b3.value == 1) || (b7.value == 1 && b4.value == 1) || (b5.value == 1 && b9.value == 1)) && b1.value == 0) {
                    b1.innerText = comp;
                    b1.value = 2;
                    b1.removeEventListener('click', play);
                    arr.splice(arr.indexOf(b1.id), 1);
                    // return;
                } else
                    if (((b1.value == 1 && b3.value == 1) || (b5.value == 1 && b8.value == 1)) && b2.value == 0) {
                        b2.innerText = comp;
                        b2.value = 2;
                        b2.removeEventListener('click', play);
                        arr.splice(arr.indexOf(b2.id), 1);
                        // return;
                    } else
                        if (((b4.value == 1 && b5.value == 1) || (b3.value == 1 && b9.value == 1)) && b6.value == 0) {
                            b6.innerText = comp;
                            b6.value = 2;
                            b6.removeEventListener('click', play);
                            arr.splice(arr.indexOf(b6.id), 1);
                            // return;
                        } else
                            if (((b5.value == 1 && b6.value == 1) || (b7.value == 1 && b1.value == 1)) && b4.value == 0) {
                                b4.innerText = comp;
                                b4.value = 2;
                                b4.removeEventListener('click', play);
                                arr.splice(arr.indexOf(b4.id), 1);
                                // return;
                            } else
                                if (((b4.value == 1 && b6.value == 1) || (b2.value == 1 && b8.value == 1) || (b1.value == 1 && b9.value == 1) || (b3.value == 1 && b7.value == 1)) && b5.value == 0) {
                                    b5.innerText = comp;
                                    b5.value = 2;
                                    b5.removeEventListener('click', play);
                                    arr.splice(arr.indexOf(b5.id), 1);
                                    // return;
                                } else
                                    if (((b7.value == 1 && b8.value == 1) || (b3.value == 1 && b6.value == 1) || (b1.value == 1 && b5.value == 1)) && b9.value == 0) {
                                        b9.innerText = comp;
                                        b9.value = 2;
                                        b9.removeEventListener('click', play);
                                        arr.splice(arr.indexOf(b9.id), 1);
                                        // return;
                                    } else
                                        if (((b8.value == 1 && b9.value == 1) || (b1.value == 1 && b4.value == 1) || (b3.value == 1 && b5.value == 1)) && b7.value == 0) {
                                            b7.innerText = comp;
                                            b7.value = 2;
                                            b7.removeEventListener('click', play);
                                            arr.splice(arr.indexOf(b7.id), 1);
                                            // return;
                                        } else
                                            if (((b7.value == 1 && b9.value == 1) || (b2.value == 1 && b5.value == 1)) && b8.value == 0) {
                                                b8.innerText = comp;
                                                b8.value = 2;
                                                b8.removeEventListener('click', play);
                                                arr.splice(arr.indexOf(b8.id), 1);
                                                // return;
                                            } else {
                                                let rand = Math.floor(Math.random() * arr.length);
                                                console.log(rand);

                                                if (arr.length > 0) {
                                                    compTurn = document.getElementById(`${arr[rand]}`);
                                                    compTurn.innerText = comp;
                                                    compTurn.value = 2;
                                                }

                                                //remove filled box
                                                compTurn.removeEventListener('click', play);
                                                arr.splice(arr.indexOf(compTurn.id), 1);
                                            }

        }
        else if (clicks >= 3) {
            if (((b1.value == 2 && b2.value == 2) || (b6.value == 2 && b9.value == 2) || (b7.value == 2 && b5.value == 2)) && b3.value == 0) {
                b3.innerText = comp;
                b3.value = 2;
                b3.removeEventListener('click', play);
                arr.splice(arr.indexOf(b3.id), 1);
                // return;
            } else
                if (((b2.value == 2 && b3.value == 2) || (b7.value == 2 && b4.value == 2) || (b5.value == 2 && b9.value == 2)) && b1.value == 0) {
                    b1.innerText = comp;
                    b1.value = 2;
                    b1.removeEventListener('click', play);
                    arr.splice(arr.indexOf(b1.id), 1);
                    // return;
                } else
                    if (((b1.value == 2 && b3.value == 2) || (b5.value == 2 && b8.value == 2)) && b2.value == 0) {
                        b2.innerText = comp;
                        b2.value = 2;
                        b2.removeEventListener('click', play);
                        arr.splice(arr.indexOf(b2.id), 1);
                        // return;
                    } else
                        if (((b4.value == 2 && b5.value == 2) || (b3.value == 2 && b9.value == 2)) && b6.value == 0) {
                            b6.innerText = comp;
                            b6.value = 2;
                            b6.removeEventListener('click', play);
                            arr.splice(arr.indexOf(b6.id), 1);
                            // return;
                        } else
                            if (((b5.value == 2 && b6.value == 2) || (b7.value == 2 && b1.value == 2)) && b4.value == 0) {
                                b4.innerText = comp;
                                b4.value = 2;
                                b4.removeEventListener('click', play);
                                arr.splice(arr.indexOf(b4.id), 1);
                                // return;
                            } else
                                if (((b4.value == 2 && b6.value == 2) || (b2.value == 2 && b8.value == 2) || (b1.value == 2 && b9.value == 2) || (b3.value == 2 && b7.value == 2)) && b5.value == 0) {
                                    b5innerText = comp;
                                    b5.value = 2;
                                    b5.removeEventListener('click', play);
                                    arr.splice(arr.indexOf(b5.id), 1);
                                    // return;
                                } else
                                    if (((b7.value == 2 && b8.value == 2) || (b3.value == 2 && b6.value == 2) || (b1.value == 2 && b5.value == 2)) && b9.value == 0) {
                                        b9.innerText = comp;
                                        b9.value = 2;
                                        b9.removeEventListener('click', play);
                                        arr.splice(arr.indexOf(b9.id), 1);
                                        // return;
                                    } else
                                        if (((b8.value == 2 && b9.value == 2) || (b1.value == 2 && b4.value == 2) || (b3.value == 2 && b5.value == 2)) && b7.value == 0) {
                                            b7.innerText = comp;
                                            b7.value = 2;
                                            b7.removeEventListener('click', play);
                                            arr.splice(arr.indexOf(b7.id), 1);
                                            // return;
                                        } else
                                            if (((b7.value == 2 && b9.value == 2) || (b2.value == 2 && b5.value == 2)) && b8.value == 0) {
                                                b8.innerText = comp;
                                                b8.value = 2;
                                                b8.removeEventListener('click', play);
                                                arr.splice(arr.indexOf(b8.id), 1);
                                                // return;


                                            } else
                                                if (((b1.value == 1 && b2.value == 1) || (b6.value == 1 && b9.value == 1) || (b7.value == 1 && b5.value == 1)) && b3.value == 0) {
                                                    b3.innerText = comp;
                                                    b3.value = 2;
                                                    b3.removeEventListener('click', play);
                                                    arr.splice(arr.indexOf(b3.id), 1);
                                                    // return;
                                                } else
                                                    if (((b2.value == 1 && b3.value == 1) || (b7.value == 1 && b4.value == 1) || (b5.value == 1 && b9.value == 1)) && b1.value == 0) {
                                                        b1.innerText = comp;
                                                        b1.value = 2;
                                                        b1.removeEventListener('click', play);
                                                        arr.splice(arr.indexOf(b1.id), 1);
                                                        // return;
                                                    } else
                                                        if (((b1.value == 1 && b3.value == 1) || (b5.value == 1 && b8.value == 1)) && b2.value == 0) {
                                                            b2.innerText = comp;
                                                            b2.value = 2;
                                                            b2.removeEventListener('click', play);
                                                            arr.splice(arr.indexOf(b2.id), 1);
                                                            // return;
                                                        } else
                                                            if (((b4.value == 1 && b5.value == 1) || (b3.value == 1 && b9.value == 1)) && b6.value == 0) {
                                                                b6.innerText = comp;
                                                                b6.value = 2;
                                                                b6.removeEventListener('click', play);
                                                                arr.splice(arr.indexOf(b6.id), 1);
                                                                // return;
                                                            } else
                                                                if (((b5.value == 1 && b6.value == 1) || (b7.value == 1 && b1.value == 1)) && b4.value == 0) {
                                                                    b4.innerText = comp;
                                                                    b4.value = 2;
                                                                    b4.removeEventListener('click', play);
                                                                    arr.splice(arr.indexOf(b4.id), 1);
                                                                    // return;
                                                                } else
                                                                    if (((b4.value == 1 && b6.value == 1) || (b2.value == 1 && b8.value == 1) || (b1.value == 1 && b9.value == 1) || (b3.value == 1 && b7.value == 1)) && b5.value == 0) {
                                                                        b5innerText = comp;
                                                                        b5.value = 2;
                                                                        b5.removeEventListener('click', play);
                                                                        arr.splice(arr.indexOf(b5.id), 1);
                                                                        // return;
                                                                    } else
                                                                        if (((b7.value == 1 && b8.value == 1) || (b3.value == 1 && b6.value == 1) || (b1.value == 1 && b5.value == 1)) && b9.value == 0) {
                                                                            b9.innerText = comp;
                                                                            b9.value = 2;
                                                                            b9.removeEventListener('click', play);
                                                                            arr.splice(arr.indexOf(b9.id), 1);
                                                                            // return;
                                                                        } else
                                                                            if (((b8.value == 1 && b9.value == 1) || (b1.value == 1 && b4.value == 1) || (b3.value == 1 && b5.value == 1)) && b7.value == 0) {
                                                                                b7.innerText = comp;
                                                                                b7.value = 2;
                                                                                b7.removeEventListener('click', play);
                                                                                arr.splice(arr.indexOf(b7.id), 1);
                                                                                // return;
                                                                            } else
                                                                                if (((b7.value == 1 && b9.value == 1) || (b2.value == 1 && b5.value == 1)) && b8.value == 0) {
                                                                                    b8.innerText = comp;
                                                                                    b8.value = 2;
                                                                                    b8.removeEventListener('click', play);
                                                                                    arr.splice(arr.indexOf(b8.id), 1);
                                                                                    // return;
                                                                                } else {
                                                                                    let rand = Math.floor(Math.random() * arr.length);
                                                                                    console.log(rand);

                                                                                    if (arr.length > 0) {
                                                                                        compTurn = document.getElementById(`${arr[rand]}`);
                                                                                        compTurn.innerText = comp;
                                                                                        compTurn.value = 2;
                                                                                    }

                                                                                    //remove filled box
                                                                                    compTurn.removeEventListener('click', play);
                                                                                    arr.splice(arr.indexOf(compTurn.id), 1);
                                                                                }
        }



    // }

    /* 
        //compuer move
        let rand = Math.floor(Math.random() * arr.length);
        console.log(rand);
    
        if (arr.length > 0) {
            compTurn = document.getElementById(`${arr[rand]}`);
            compTurn.innerText = comp;
            compTurn.value = 2;
        }
    
        //remove filled box
        compTurn.removeEventListener('click', play);
        arr.splice(arr.indexOf(compTurn.id), 1);
        // console.log(...arr); */


    if (arr.length <= 1 && !checkPlayer() && !checkComputer()) {
        chat.value = `We have a tie! `;
        setTimeout(reset, 3000);
        return;
    }

    setTimeout(checkComputer, 1000);

    playerTurn = true;
    chat.value = 'Your turn again';

}


function reset() {
    // alert('Hiiii');
    [b1, b2, b3, b4, b5, b6, b7, b8, b9].forEach(i => {
        i.value = 0;
    });

    [b1, b2, b3, b4, b5, b6, b7, b8, b9].forEach(i => {
        i.innerText = '';
    });

    clicks = 0;
    chat.value = 'Your turn';
    title.innerText = 'Hello again';
    playerTurn = true;
    arr = ['box1', 'box2', 'box3', 'box4', 'box5', 'box6', 'box7', 'box8', 'box9'];
    Array.from(boxes).forEach(div => {
        div.addEventListener('click', play);
    });
    welcome.style.display = 'initial';
    chatRes.style.display = 'none';
    bgi.classList.remove('reveal');

}


function checkPlayer() {

    if (clicks >= 3) {

        if (b1.value == 1 && b2.value == 1 && b3.value == 1) {
            // alert(`Congrats ${player} Youre a winner ❤️❤️❤️ `);
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b4.value == 1 && b5.value == 1 && b6.value == 1) {
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b7.value == 1 && b8.value == 1 && b9.value == 1) {
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b1.value == 1 && b4.value == 1 && b7.value == 1) {
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b2.value == 1 && b5.value == 1 && b8.value == 1) {
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b3.value == 1 && b6.value == 1 && b9.value == 1) {
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b1.value == 1 && b5.value == 1 && b9.value == 1) {
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b3.value == 1 && b5.value == 1 && b7.value == 1) {
            chat.value = `Congrats ${player} Youre a winner ❤️❤️❤️ `;
            setTimeout(reset, 3000);
            return 1;
        }
        return;
    }
}

function checkComputer() {

    if (clicks >= 3) {

        if (b1.value + b2.value + b3.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b4.value + b5.value + b6.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b7.value + b8.value + b9.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b1.value + b4.value + b7.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b2.value + b5.value + b8.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b3.value + b6.value + b9.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b1.value + b5.value + b9.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        if (b3.value + b5.value + b7.value == 6) {
            chat.value = ` Sorry dear, You just lost 😂😂😂  `;
            setTimeout(reset, 3000);
            return 1;
        }
        return;
    }
}




